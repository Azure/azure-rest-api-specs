# Microsoft Azure CLI 'cosmosdb-preview' Extension #


