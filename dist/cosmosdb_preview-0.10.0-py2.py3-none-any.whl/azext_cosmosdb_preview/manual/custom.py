import uuid

def cosmosdb_data_transfer_job_create2(client,
                                      resource_group_name,
                                      account_name,
                                      job_name,
                                      source,
                                      destination):
    job_create_properties = {}
    job_create_properties['source'] = source
    job_create_properties['destination'] = destination
    job_create_parameters = {}
    job_create_parameters['properties'] = job_create_properties
    return client.create(resource_group_name=resource_group_name,
                         account_name=account_name,
                         job_name=job_name,
                         job_create_parameters=job_create_parameters)                                    


def cosmosdb_data_transfer_cassandra_export_job(client,
                                      resource_group_name,
                                      account_name,
                                      keyspace_name,
                                      table_name,
                                      storage_container,
                                      storage_url,
                                      job_name=None):
    job_source = {}
    job_source['component'] = 'CosmosDBCassandra'
    job_source['keyspace_name'] = keyspace_name
    job_source['table_name'] = table_name

    job_destination = {}
    job_destination['component'] = 'AzureBlobStorage'
    job_destination['container_name'] = storage_container
    job_destination['endpoint_url'] = storage_url

    job_create_properties = {}
    job_create_properties['source'] = job_source
    job_create_properties['destination'] = job_destination

    job_create_parameters = {}
    job_create_parameters['properties'] = job_create_properties

    if job_name is None:
        job_name = uuid.uuid4()

    return client.create(resource_group_name=resource_group_name,
                         account_name=account_name,
                         job_name=job_name,
                         job_create_parameters=job_create_parameters)

def cosmosdb_data_transfer_cassandra_import_job(client,
                                      resource_group_name,
                                      account_name,
                                      keyspace_name,
                                      table_name,
                                      storage_container,
                                      storage_url,
                                      job_name=None):
    job_source = {}
    job_source['component'] = 'AzureBlobStorage'
    job_source['container_name'] = storage_container
    job_source['endpoint_url'] = storage_url
    
    job_destination = {}
    job_destination['component'] = 'CosmosDBCassandra'
    job_destination['keyspace_name'] = keyspace_name
    job_destination['table_name'] = table_name

    job_create_properties = {}
    job_create_properties['source'] = job_source
    job_create_properties['destination'] = job_destination

    job_create_parameters = {}
    job_create_parameters['properties'] = job_create_properties

    if job_name is None:
        job_name = uuid.uuid4()

    return client.create(resource_group_name=resource_group_name,
                         account_name=account_name,
                         job_name=job_name,
                         job_create_parameters=job_create_parameters)